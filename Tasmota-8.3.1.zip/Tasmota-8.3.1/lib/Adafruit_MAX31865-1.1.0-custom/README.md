# Adafruit_MAX31865
Arduino Library for Adafruit MAX31865 RTD Sensor
